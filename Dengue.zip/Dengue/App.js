import React, { useState } from 'react';
import { View, Text, Modal, TouchableOpacity, Image, ImageBackground, StyleSheet } from 'react-native';

const App = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState('');
  const [modalImage, setModalImage] = useState(null);

  const showModal = (content, image) => {
    setModalContent(content);
    setModalImage(image);
    setModalVisible(true);
  };

  return (
    <ImageBackground source={require('./assets/fundoDengue.gif')} style={styles.backgroundImage}>
      <View style={styles.container}>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-A dengue é uma doença viral transmitida principalmente pelos mosquitos Aedes aegypti e Aedes albopictus.", require('./assets/Dengue.svg'))}>
          <Text style={styles.buttonText}> O que é Dengue? </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n- Febre alta,\n- Dor de cabeça intensa,\n- Dor atrás dos olhos,\n- Dores musculares e articulares,\n- Náuseas e vômitos,\n- Erupção cutânea,\n- Sangramento do nariz ou das gengivas", require('./assets/Sintomas.svg'))}>
          <Text style={styles.buttonText}> Sintomas da Dengue </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-O diagnóstico é feito através de exames de sangue para detectar a presença do vírus da dengue.", require('./assets/Diagnóstico.svg'))}>
          <Text style={styles.buttonText}> Diagnóstico </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-Não há tratamento específico para a dengue.\n- O tratamento é principalmente de suporte, focado no alívio dos sintomas.\n- Hidratação adequada é fundamental para prevenir a desidratação, especialmente em casos graves.", require('./assets/Tratamento.svg'))}>
          <Text style={styles.buttonText}> Tratamento </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-A prevenção da dengue envolve várias medidas, incluindo:\n- Eliminação de criadouros de mosquitos, como água parada em recipientes, pneus velhos, vasos de plantas, etc.\n- Uso de repelentes de insetos.\n- Uso de telas em portas e janelas.\n- Uso de roupas que cubram a maior parte do corpo, especialmente durante o amanhecer e o entardecer, quando os mosquitos são mais ativos.", require('./assets/Prevenção.svg'))}>
          <Text style={styles.buttonText}> Prevenção </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-Dengue Clássica: A forma mais comum da doença, com sintomas de febre alta, dores musculares e articulares, dor de cabeça, etc.\n- Dengue Hemorrágica: Uma forma mais grave da doença, que pode levar a complicações como sangramento grave, choque e até mesmo a morte.", require('./assets/Tipos.svg'))}>
          <Text style={styles.buttonText}> Tipos de Dengue </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-A dengue é uma doença endêmica em muitas partes do mundo, principalmente em áreas tropicais e subtropicais.\n- A transmissão ocorre principalmente durante a estação chuvosa, quando há um aumento na reprodução dos mosquitos.", require('./assets/Epidemiologia.svg'))}>
          <Text style={styles.buttonText}> Epidemiologia </Text>
        </TouchableOpacity>
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              {modalImage && <Image source={modalImage} style={styles.modalImage} />}
              <Text style={styles.modalText}>{modalContent}</Text>
              <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
                <Text style={styles.closeButtonText}>Fechar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({

  container: {

    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',

  },

  backgroundImage: {

    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',

  },

  button: {

    flexDirection: 'row',
    backgroundColor: '#640101',
    padding: 8,
    margin: 10,
    borderRadius: 5,
    width: 220,
    alignItems: 'center',

  },

  buttonText: {

    color: '#fff',
    fontSize: 18,
    fontWeight:'bold',
    marginLeft: 10,
    alignItems: 'center',

  },

  modalView: {

    margin: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    elevation: 5,

  },

  modalText: {

    marginBottom: 13,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,

  },

  modalImage: {

    width: 300,
    height: 200,

  },

  closeButton: {

    backgroundColor: '#640101',
    padding: 10,
    margin: 10,
    borderRadius: 5,
    width: 100,
    alignItems: 'center',

  },

  closeButtonText: {

    color: '#fff',
    fontSize: 18,

  },

});

export default App;
