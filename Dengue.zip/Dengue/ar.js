import React, { useState } from 'react';
import { View, Text, Modal, TouchableOpacity, ImageBackground, StyleSheet } from 'react-native';

const App = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState('');

  const showModal = (content) => {
    setModalContent(content);
    setModalVisible(true);
  };

  return (
    <ImageBackground source={require('./assets/fundoDengue.gif')} style={styles.backgroundImage}>
      <View style={styles.container}>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-A dengue é uma doença viral transmitida principalmente pelos mosquitos Aedes aegypti e Aedes albopictus.")}>
          <Text style={styles.buttonText}> O que é Dengue? </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n- Febre alta,\n- Dor de cabeça intensa,\n- Dor atrás dos olhos,\n- Dores musculares e articulares,\n- Náuseas e vômitos,\n- Erupção cutânea,\n- Sangramento do nariz ou das gengivas")}>
          <Text style={styles.buttonText}> Sintomas da Dengue </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-O diagnóstico é feito através de exames de sangue para detectar a presença do vírus da dengue.")}>
          <Text style={styles.buttonText}> Diagnóstico </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-Não há tratamento específico para a dengue.\n- O tratamento é principalmente de suporte, focado no alívio dos sintomas.\n- Hidratação adequada é fundamental para prevenir a desidratação, especialmente em casos graves.")}>
          <Text style={styles.buttonText}> Tratamento </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-A prevenção da dengue envolve várias medidas, incluindo:\n- Eliminação de criadouros de mosquitos, como água parada em recipientes, pneus velhos, vasos de plantas, etc.\n- Uso de repelentes de insetos.\n- Uso de telas em portas e janelas.\n- Uso de roupas que cubram a maior parte do corpo, especialmente durante o amanhecer e o entardecer, quando os mosquitos são mais ativos.")}>
          <Text style={styles.buttonText}> Prevenção </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-Dengue Clássica: A forma mais comum da doença, com sintomas de febre alta, dores musculares e articulares, dor de cabeça, etc.\n- Dengue Hemorrágica: Uma forma mais grave da doença, que pode levar a complicações como sangramento grave, choque e até mesmo a morte.")}>
          <Text style={styles.buttonText}> Tipos de Dengue </Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => showModal("\n-A dengue é uma doença endêmica em muitas partes do mundo, principalmente em áreas tropicais e subtropicais.\n- A transmissão ocorre principalmente durante a estação chuvosa, quando há um aumento na reprodução dos mosquitos.")}>
          <Text style={styles.buttonText}> Epidemiologia </Text>
        </TouchableOpacity>
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <Text style={styles.modalText}>{modalContent}</Text>
              <TouchableOpacity style={styles.closeButton} onPress={() => setModalVisible(false)}>
                <Text style={styles.closeButtonText}>Fechar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({

  container: {

    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',

  },

  backgroundImage: {

    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',

  },

  button: {

    backgroundColor: '#640101',
    padding: 10,
    margin: 10,
    borderRadius: 5,
    width: 200,
    alignItems: 'center',

  },

  buttonText: {

    color: '#fff',
    fontSize: 18,

  },

  modalView: {

    margin: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.8)', // Defina um valor de transparência adequado para a imagem de fundo
    borderRadius: 20,
    padding: 35,
    alignItems: 'center',
    elevation: 5,

  },

  modalText: {

    marginBottom: 15,
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,

  },

  closeButton: {

    backgroundColor: '#640101',
    padding: 10,
    margin: 10,
    borderRadius: 5,
    width: 100,
    alignItems: 'center',

  },

  closeButtonText: {

    color: '#fff',
    fontSize: 18,

  },
  
});

export default App;
